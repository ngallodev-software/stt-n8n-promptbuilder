# PromptForge Starter Codebase

## Quick start

### 1. Create virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install package

```bash
pip install -U pip
pip install -e .
```

### 3. Copy environment file

```bash
cp .env.example .env
```

### 4. Start services API

```bash
uvicorn promptforge_services.api:app --host 0.0.0.0 --port 8090 --reload
```

### 5. Run watcher

```bash
python -m promptforge_watcher
```

This scaffold is intentionally thin. The real implementation should follow the technical spec artifacts.
