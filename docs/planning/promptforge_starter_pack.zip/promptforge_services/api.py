from fastapi import FastAPI

app = FastAPI(title="PromptForge Services")

@app.get("/health")
def health() -> dict:
    return {"ok": True}

@app.post("/preprocess")
def preprocess(payload: dict) -> dict:
    return {"status": "todo", "received": payload}

@app.post("/validate")
def validate(payload: dict) -> dict:
    return {"status": "todo", "received": payload}

@app.post("/render")
def render(payload: dict) -> dict:
    return {"status": "todo", "received": payload}
