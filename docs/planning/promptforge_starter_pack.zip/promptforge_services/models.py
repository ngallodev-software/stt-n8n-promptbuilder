from pydantic import BaseModel, Field
from typing import Literal

Destination = Literal["chat", "cli", "obsidian_note", "queue_only"]
PromptType = Literal["general", "coding-cli", "delegation", "planning", "review"]
Mode = Literal["draft", "queue", "auto_dispatch"]

class BaseContract(BaseModel):
    contract_name: str
    requires_review: bool = False
    notes: list[str] = Field(default_factory=list)

class AgentTaskV1(BaseContract):
    contract_name: Literal["agent_task_v1"]
    intent: Literal["agent_task"]
    project_slug: str
    prompt_type: PromptType
    destination: Destination
    target_identifier: str | None = None
    mode: Mode = "queue"
    final_prompt_markdown: str
