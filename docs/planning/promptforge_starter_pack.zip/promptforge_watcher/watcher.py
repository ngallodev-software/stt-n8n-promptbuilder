from pathlib import Path
from .config import WatcherConfig

def run() -> None:
    cfg = WatcherConfig()
    watch_path = Path(cfg.vault_path) / cfg.watch_folder
    print(f"PromptForge watcher starting. Watching: {watch_path}")
    # TODO:
    # - add file stabilization logic
    # - parse markdown notes
    # - write intake records to Postgres
    # - trigger n8n webhook
