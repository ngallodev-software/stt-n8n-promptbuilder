from pydantic import BaseModel
import os

class WatcherConfig(BaseModel):
    vault_path: str = os.getenv("PROMPTFORGE_VAULT_PATH", "/vault")
    watch_folder: str = os.getenv("PROMPTFORGE_WATCH_FOLDER", "Inbox/Voice")
    webhook_url: str = os.getenv("PROMPTFORGE_N8N_WEBHOOK_URL", "http://n8n:5678/webhook/promptforge-intake")
